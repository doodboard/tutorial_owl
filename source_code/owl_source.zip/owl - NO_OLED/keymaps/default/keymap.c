/*
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H


enum layers{
    _BASE,
    _FN,
    _RGB
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS]  = {
    [_BASE] = LAYOUT_ALICE(
KC_MUTE,
KC_ESC ,KC_1   ,KC_2   ,  KC_3   ,KC_4   ,KC_5   ,KC_6   ,  KC_7   ,KC_8   ,KC_9   ,KC_0   ,  KC_MINS,KC_EQL , KC_BSPC,
KC_TAB ,KC_Q   ,      KC_W   ,KC_E   ,KC_R   ,KC_T   ,  KC_Y   ,KC_U   ,KC_I   ,KC_O   ,  KC_P   ,KC_LBRC,KC_RBRC, KC_PIPE,
KC_CAPS,KC_A   ,  KC_S   ,KC_D   ,KC_F   ,KC_G   ,          KC_H   ,KC_J   ,KC_K   ,KC_L   ,  KC_SCLN,KC_QUOT,KC_ENT ,
KC_LSFT,  KC_Z   ,    KC_X   ,KC_C   ,KC_V   ,KC_B   ,  KC_B   ,KC_N   ,KC_M   ,KC_COMM,  KC_DOT ,KC_SLSH,KC_UP,KC_RSFT,
KC_LCTL,KC_LGUI,          KC_LALT,MO(_FN) ,KC_SPC ,          KC_SPC ,MO(_RGB) ,KC_RALT,              KC_LEFT,KC_DOWN,KC_RIGHT
    ),
    [_FN] = LAYOUT_ALICE(
KC_TRNS,
KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS, KC_TRNS,
KC_TRNS,KC_TRNS,      KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS, KC_TRNS,
KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,
KC_TRNS,KC_TRNS  ,    KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_PGUP,KC_TRNS,
KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,              KC_HOME,KC_PGDN,KC_END
    ),
    [_RGB] = LAYOUT_ALICE(
KC_TRNS,
RESET,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  RGB_TOG, RGB_MOD, KC_TRNS,
KC_TRNS,KC_TRNS,      KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  RGB_HUI, RGB_SAI, RGB_VAI, KC_TRNS,
KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,RGB_HUD, RGB_SAD, RGB_VAD,KC_TRNS,
KC_TRNS,KC_TRNS  ,    KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,  KC_TRNS,KC_TRNS,KC_TRNS,KC_TRNS,
KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,          KC_TRNS,KC_TRNS,KC_TRNS,              KC_TRNS,KC_TRNS,KC_TRNS
    )
    

};


bool encoder_update_user(uint8_t index, bool clockwise) {
    if (index == 0) { /* First encoder */
        if (clockwise) {
            tap_code(KC_VOLU);
        } else {
            tap_code(KC_VOLD);
        }
    }
    return true;
}

void keyboard_post_init_user(void) {
  // Customise these values to desired behaviour
  //debug_enable=true;
  //debug_matrix=true;
  //debug_keyboard=true;
  //debug_mouse=true;
}

#ifdef OLED_ENABLE
oled_rotation_t oled_init_user(oled_rotation_t rotation) { return OLED_ROTATION_90; }


// WPM-responsive animation stuff here
#define IDLE_FRAMES 2
#define IDLE_SPEED 40 // below this wpm value your animation will idle

#define ANIM_FRAME_DURATION 200 // how long each frame lasts in ms
// #define SLEEP_TIMER 60000 // should sleep after this period of 0 wpm, needs fixing
#define ANIM_SIZE 636 // number of bytes in array, minimize for adequate firmware size, max is 1024

uint32_t anim_timer = 0;
uint32_t anim_sleep = 0;
uint8_t current_idle_frame = 0;

// Credit to u/Pop-X- for the initial code. You can find his commit here https://github.com/qmk/qmk_firmware/pull/9264/files#diff-303f6e3a7a5ee54be0a9a13630842956R196-R333.
static void render_anim(void) {
    static const char PROGMEM idle[IDLE_FRAMES][ANIM_SIZE] = {
        {
        0,  0,  0,240, 16, 16, 48, 96,192,128,128,192,224,224,224,224,224,224,224,224,192,128,128,192,224,112, 48, 16, 16,240,  0,  0,  0,  0,  0,  3,  3,254,  3,249,140,  6,  6, 38,142,254,252,249,  3,249,140,  6,  6, 38,142,254,252,249,  3,254,  3,  3,  0,  0,  0,  0,  0,128, 96, 25,  6,  4,  9, 11, 11, 11,139,107, 53,  8, 16,  8,  5, 11, 11, 11,251, 11,  9,  4,250,  1,  0,  0,  0,  0,  0,  0,  0, 31, 32,192, 32, 16, 16,  8,132,130,129,128,128,128,192, 96, 80,208, 76, 35,
        16,144,140,195,192,192,224,224,240,240,192,192,128,128,128,143,136,196,194,241,136,232,135,232,136,248,124, 98,122, 33, 58, 19, 31, 63, 63, 63,119, 99,193,129,  1,  0,  7,  7, 15, 15, 15, 15, 15, 15, 15,  7,  7,  3,  3,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  3,  2,  0,
        },
        {
        0,  0,  0,248,136,  8,152,176, 96, 64, 64, 96,112,112,112,240,240,240,112,112, 96, 64, 64, 96,112,184,152,  8,136,248,  0,  0,  0,  0,  0,  1,  1,255,  1,124,198,131,131,147,199,255,254,124,  1,124,198,131,131,147,199,255,254,124,  1,255,  1,  1,  0,  0,  0,  0,  0,192, 48, 12,  3,  2,  4,  5,  5,  5,197, 53, 26,  4,  8,  4,  2,  5,  5,133,125,  5,  4,130,125,  0,  0,  0,  0,  0,  0,  0,  0, 15, 16,224, 16,  8,  8,132, 66, 65,192, 64, 64, 64, 96, 48, 40,232, 38, 17, 
        8,136,134,193,192,192,224,224,240,240,192,192,128,128,128,135,132,194,193,240,136,232,135,232,136,248,124, 98,122, 33, 58, 19, 31, 63, 63, 63,119, 99,193,129,  1,  0,  7,  7, 15, 15, 15, 15, 15, 15, 15,  7,  7,  3,  3,  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  3,  2,  0,
        }
    };

    //assumes 1 frame prep stage
    void animation_phase(void) {
            current_idle_frame = (current_idle_frame + 1) % IDLE_FRAMES;
            oled_write_raw_P(idle[abs((IDLE_FRAMES-1)-current_idle_frame)], ANIM_SIZE);
    }

        if(timer_elapsed32(anim_timer) > ANIM_FRAME_DURATION) {
            anim_timer = timer_read32();
            animation_phase();
        }
    }

bool oled_task_user(void) {
        render_anim();
        oled_set_cursor(0,6);
        oled_write_P(PSTR("-----\n"), false);
        oled_write_P(PSTR("DDBD "), false);
        oled_write_P(PSTR("OWL  \n"), false);
        oled_write_P(PSTR("-----\n"), false);
    // Host Keyboard Layer Status
        oled_write_P(PSTR("MODE "), false);

    switch (get_highest_layer(layer_state)) {
        case _BASE:
            oled_write_P(PSTR("BASE\n"), false);
            break;
        case _FN:
            oled_write_P(PSTR("FUNC\n"), false);
            break;
        case _RGB:
            oled_write_P(PSTR("RGB\n"), false);
            break;
    }
    return false;
}
#endif
